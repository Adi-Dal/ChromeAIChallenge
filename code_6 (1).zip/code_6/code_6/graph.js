// Use cytoscape from global (loaded via CDN in graph.html)
const cytoscape = window.cytoscape

// Fallback mock graph data
const mockGraphData = {
  nodes: [
    { id: "current", label: "Current Page", type: "page-current", url: "", summary: "" },
    {
      id: "ent:reinforcement-learning",
      label: "Reinforcement Learning",
      type: "entity",
      entityType: "Concept",
    },
    {
      id: "page:example",
      label: "Some Related Page",
      type: "page",
      url: "https://example.com/related",
      summary: "Example related page used as a fallback graph node.",
    },
  ],
  edges: [
    { source: "current", target: "ent:reinforcement-learning", similarity: 0.7, relType: "MENTIONS" },
    { source: "ent:reinforcement-learning", target: "page:example", similarity: 0.45, relType: "MENTION_SHARED" },
  ],
}

let cy
let graphData = mockGraphData

// Initialize graph
document.addEventListener("DOMContentLoaded", async () => {
  await hydrateGraphFromIndexedDB()
  initializeGraph()
  setupEventListeners()
})

async function hydrateGraphFromIndexedDB() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true })
    const activeUrl = tab?.url
    const activeTitle = tab?.title || 'Current Page'
    const pages = (await window.MemoryPalDB?.getAllPages?.()) || []
    if (!pages.length) return

    const activePage = pages.find((p) => p.url === activeUrl) || pages[0]
    const pageNodeId = activePage.id

    const nodeMap = new Map()
    const edges = []
    const entityCache = new Map()
    const missingEntityIds = new Set()

    const addNode = (node) => {
      if (!node?.id) return
      const existing = nodeMap.get(node.id)
      if (existing) {
        nodeMap.set(node.id, { ...existing, ...node })
      } else {
        nodeMap.set(node.id, node)
      }
    }

    const clampSimilarity = (value) => Math.max(0.12, Math.min(1, value))

    addNode({
      id: pageNodeId,
      label: activePage.title || activeTitle,
      type: 'page-current',
      url: activePage.url,
      summary: activePage.summary,
    })

    const rels = await window.MemoryPalDB.getRelationsBySource('page', pageNodeId)
    const mentionRels = rels
      .filter((r) => r.relType === 'MENTIONS')
      .sort((a, b) => (b.weight || 1) - (a.weight || 1))
      .slice(0, 8)
    const entityIds = mentionRels.map((r) => r.targetId)
    const entities = await window.MemoryPalDB.getEntitiesByIds(entityIds)
    for (const ent of entities) entityCache.set(ent.id, ent)

    for (const ent of entities) {
      addNode({
        id: ent.id,
        label: ent.name,
        type: 'entity',
        entityType: ent.type,
      })

      const weight = (mentionRels.find((r) => r.targetId === ent.id)?.weight || 1)
      const normalized = clampSimilarity(0.2 + Math.log1p(weight))
      edges.push({
        source: pageNodeId,
        target: ent.id,
        similarity: normalized,
        relType: 'MENTIONS',
      })

      const incoming = await window.MemoryPalDB.getRelationsByTarget('entity', ent.id)
      const relatedPageIds = Array.from(
        new Set(
          incoming
            .filter((r) => r.sourceType === 'page' && r.sourceId !== pageNodeId)
            .map((r) => r.sourceId)
        )
      ).slice(0, 4)

      if (relatedPageIds.length) {
        const relatedPages = await window.MemoryPalDB.getPagesByIds(relatedPageIds)
        for (const page of relatedPages) {
          addNode({
            id: page.id,
            label: page.title || page.url,
            type: 'page',
            url: page.url,
            summary: page.summary,
          })
          edges.push({
            source: ent.id,
            target: page.id,
            similarity: 0.45,
            relType: 'MENTION_SHARED',
          })
        }
      }

      const coRelations = await window.MemoryPalDB.getRelationsBySource('entity', ent.id)
      const coTargets = coRelations
        .filter((r) => r.relType === 'CO_MENTION')
        .sort((a, b) => (b.weight || 1) - (a.weight || 1))
        .slice(0, 4)

      for (const rel of coTargets) {
        if (!entityCache.has(rel.targetId)) missingEntityIds.add(rel.targetId)
        const target = entityCache.get(rel.targetId)
        addNode({
          id: rel.targetId,
          label: target?.name || rel.targetId,
          type: 'entity',
          entityType: target?.type,
        })
        edges.push({
          source: ent.id,
          target: rel.targetId,
          similarity: clampSimilarity(0.3 + (rel.weight || 0) / 5),
          relType: 'CO_MENTION',
        })
      }
    }

    if (missingEntityIds.size) {
      const extras = await window.MemoryPalDB.getEntitiesByIds(Array.from(missingEntityIds))
      for (const ent of extras) {
        entityCache.set(ent.id, ent)
        const existing = nodeMap.get(ent.id)
        if (existing) {
          existing.label = ent.name || existing.label
          existing.entityType = ent.type || existing.entityType
          nodeMap.set(ent.id, existing)
        } else {
          addNode({ id: ent.id, label: ent.name, type: 'entity', entityType: ent.type })
        }
      }
    }

    const similarPageRels = rels
      .filter((r) => r.relType === 'PAGE_SIMILAR')
      .sort((a, b) => (b.weight || 0) - (a.weight || 0))
      .slice(0, 8)
    if (similarPageRels.length) {
      const similarIds = similarPageRels.map((r) => r.targetId)
      const similarPages = await window.MemoryPalDB.getPagesByIds(similarIds)
      for (const rel of similarPageRels) {
        const page = similarPages.find((p) => p.id === rel.targetId)
        if (!page) continue
        addNode({
          id: page.id,
          label: page.title || page.url,
          type: 'page',
          url: page.url,
          summary: page.summary,
        })
        edges.push({
          source: pageNodeId,
          target: page.id,
          similarity: clampSimilarity(rel.weight || 0.2),
          relType: 'PAGE_SIMILAR',
        })
      }
    }

    graphData = {
      nodes: Array.from(nodeMap.values()),
      edges: edges.map((edge) => ({
        ...edge,
        similarity: clampSimilarity(edge.similarity),
      })),
    }
  } catch (e) {
    console.warn('Graph hydration failed, using mock data', e)
  }
}

function initializeGraph() {
  cy = cytoscape({
    container: document.getElementById("cy"),

    elements: [
      ...graphData.nodes.map((node) => ({
        data: {
          id: node.id,
          label: node.label,
          type: node.type,
          url: node.url,
          summary: node.summary,
          entityType: node.entityType,
        },
      })),
      ...graphData.edges.map((edge) => ({
        data: {
          source: edge.source,
          target: edge.target,
          similarity: edge.similarity,
          relType: edge.relType,
        },
      })),
    ],

    style: [
      {
        selector: "node",
        style: {
          "background-color": "#8b5cf6",
          label: "data(label)",
          color: "#e8eaed",
          "text-valign": "center",
          "text-halign": "center",
          "font-size": "12px",
          "font-weight": "600",
          width: "60px",
          height: "60px",
          "border-width": "2px",
          "border-color": "#2a3441",
          "text-wrap": "wrap",
          "text-max-width": "80px",
        },
      },
      {
        selector: 'node[type="page-current"]',
        style: {
          "background-color": "#0ea5e9",
          width: "80px",
          height: "80px",
          "border-width": "3px",
          "border-color": "#0ea5e9",
          "box-shadow": "0 0 30px rgba(14, 165, 233, 0.6)",
        },
      },
      {
        selector: 'node[type="entity"]',
        style: {
          "background-color": "#22c55e",
          "border-color": "#14532d",
          "border-width": "2px",
        },
      },
      {
        selector: 'node[type="page"]',
        style: {
          "background-color": "#a855f7",
          "border-color": "#4c1d95",
          "border-width": "2px",
        },
      },
      {
        selector: "edge",
        style: {
          width: "mapData(similarity, 0, 1, 1, 4)",
          "line-color": "#0ea5e9",
          opacity: "mapData(similarity, 0, 1, 0.2, 0.8)",
          "curve-style": "bezier",
        },
      },
      {
        selector: 'edge[relType = "PAGE_SIMILAR"]',
        style: {
          "line-color": "#f97316",
          "target-arrow-color": "#f97316",
          "line-style": "solid",
        },
      },
      {
        selector: 'edge[relType = "CO_MENTION"]',
        style: {
          "line-style": "dashed",
          "line-color": "#22c55e",
          "target-arrow-color": "#22c55e",
        },
      },
      {
        selector: 'edge[relType = "MENTION_SHARED"]',
        style: {
          "line-color": "#6366f1",
          "target-arrow-color": "#6366f1",
        },
      },
      {
        selector: "node:selected",
        style: {
          "border-color": "#0ea5e9",
          "border-width": "4px",
        },
      },
    ],

    layout: {
      name: "cose",
      animate: true,
      animationDuration: 1000,
      nodeRepulsion: 8000,
      idealEdgeLength: 100,
      edgeElasticity: 100,
      nestingFactor: 1.2,
      gravity: 1,
      numIter: 1000,
      randomize: false,
    },
  })

  // Node click event
  cy.on("tap", "node", (evt) => {
    const node = evt.target
    showNodeInfo(node)
  })

  // Node hover effect
  cy.on("mouseover", "node", (evt) => {
    const node = evt.target
    node.style("border-width", "4px")
  })

  cy.on("mouseout", "node", (evt) => {
    const node = evt.target
    if (!node.selected()) {
      node.style("border-width", node.data("type") === "current" ? "3px" : "2px")
    }
  })
}

function showNodeInfo(node) {
  const infoPanel = document.getElementById("infoPanel")
  const infoContent = document.getElementById("infoContent")

  const nodeData = node.data()
  const connectedEdges = node.connectedEdges()
  const connections = connectedEdges.length
  const nodeTypeLabel =
    nodeData.type === 'entity'
      ? `${nodeData.entityType || 'Entity'}`
      : nodeData.type === 'page-current'
      ? 'Current Page'
      : 'Page'
  const description =
    nodeData.type === 'entity'
      ? `Identified <strong>${nodeTypeLabel}</strong> from your browsing context.`
      : nodeData.summary
      ? nodeData.summary
      : 'Related page discovered from your local knowledge graph.'

  const connectionItems = connectedEdges.slice(0, 6).map((edge) => {
    const otherNode =
      edge.source().id() === node.id() ? edge.target() : edge.source()
    const label = otherNode.data('label') || otherNode.id()
    const relType = edge.data('relType') || 'related'
    const score = edge.data('similarity')
    return `<li><strong>${label}</strong><span class="ms-2 badge bg-secondary text-uppercase">${relType}</span><span class="float-end text-muted">${(score * 100).toFixed(0)}%</span></li>`
  })

  const connectionsHtml = connectionItems.length
    ? `<div class="node-meta mt-3">
        <div class="meta-row">
          <span class="meta-label">Connections (${connections})</span>
        </div>
        <ul class="list-unstyled node-connection-list">${connectionItems.join('')}</ul>
      </div>`
    : ''

  const includeButton = nodeData.type === 'page' || nodeData.type === 'page-current'
  const actionButton = includeButton
    ? `<button class="btn btn-primary btn-sm w-100 mt-3" id="openNodeBtn">
          <i class="bi bi-box-arrow-up-right me-2"></i>
          Open Page
        </button>`
    : ''

  infoContent.innerHTML = `
    <h4 class="node-title">${nodeData.label}</h4>
    <p class="node-description">${description}</p>
    <div class="node-meta">
      <div class="meta-row">
        <span class="meta-label">Type</span>
        <span class="meta-value">${nodeTypeLabel}</span>
      </div>
      <div class="meta-row">
        <span class="meta-label">Connections</span>
        <span class="meta-value">${connections}</span>
      </div>
    </div>
    ${connectionsHtml}
    ${actionButton}
  `

  if (includeButton) {
    document.getElementById("openNodeBtn")?.addEventListener("click", () => {
      tryOpenNode(nodeData.id, nodeData.url)
    })
  }

  infoPanel.classList.add("active")
}

window.tryOpenNode = (nodeId, directUrl) => {
  if (directUrl) {
    window.open(directUrl, '_blank')
    return
  }
  if (!nodeId) return
  window.MemoryPalDB.getPagesByIds([nodeId]).then((pages) => {
    const p = pages[0]
    if (p?.url) window.open(p.url, '_blank')
  })
}

function setupEventListeners() {
  // Back button
  document.getElementById("backBtn").addEventListener("click", () => {
    window.history.back()
  })

  // Zoom controls
  document.getElementById("zoomInBtn").addEventListener("click", () => {
    cy.zoom(cy.zoom() * 1.2)
    cy.center()
  })

  document.getElementById("zoomOutBtn").addEventListener("click", () => {
    cy.zoom(cy.zoom() * 0.8)
    cy.center()
  })

  // Fit to screen
  document.getElementById("fitBtn").addEventListener("click", () => {
    cy.fit()
  })

  // Reset layout
  document.getElementById("resetBtn").addEventListener("click", () => {
    cy.layout({
      name: "cose",
      animate: true,
      animationDuration: 1000,
    }).run()
  })

  // Close info panel
  document.getElementById("closeInfoBtn").addEventListener("click", () => {
    document.getElementById("infoPanel").classList.remove("active")
  })
}
