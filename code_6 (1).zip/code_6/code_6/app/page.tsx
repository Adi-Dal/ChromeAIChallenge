"use client"

import  from "../graph"

export default function SyntheticV0PageForDeployment() {
  return < />
}